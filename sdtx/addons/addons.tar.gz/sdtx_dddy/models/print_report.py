# -*- coding: utf-8 -*-
from openerp.osv import fields, osv
import httplib, urllib
class Report(osv.Model):
    _inherit = 'report'

    def render(self, cr, uid, ids, template, values=None, context=None):

        if values is None:
            values = {}
        else:
            if values['doc_ids']:
                for doc_id in values['doc_ids']:
                    doc_model = values['doc_model']
                    if doc_model == 'sdtx.dddy':
                        sdtx_dddy_obj = self.pool['sdtx.dddy']
                        sdtx_dddy_id_obj = sdtx_dddy_obj.search(cr, uid, [('id', '=', doc_id)])
                        print sdtx_dddy_id_obj
                        if sdtx_dddy_id_obj:
                            sdtx_dddy_print_obj = sdtx_dddy_obj.browse(cr, uid, sdtx_dddy_id_obj[0])
                            sdtx_dddy_obj.write(cr, uid, sdtx_dddy_print_obj.id,{'is_print': 'yes'}, context)
            return super(Report, self).render(cr, uid, ids, template, values, context)
    # def httplib(self,values=None):
    #     if values is None:
    #         values = {}
    #         return
    #     else:
    #         httpClient = None
    #         try:
    #             params = urllib.urlencode({'name': 'tom', 'age': 22})
    #             headers = {"Content-type": "application/x-www-form-urlencoded"
    #                 , "Accept": "text/plain"}
    #
    #             httpClient = httplib.HTTPConnection("localhost", 80, timeout=30)
    #             httpClient.request("POST", "/test.php", params, headers)
    #
    #             response = httpClient.getresponse()
    #             print response.status
    #             print response.reason
    #             print response.read()
    #             print response.getheaders() #获取头信息
    #         except Exception, e:
    #             print e
    #         finally:
    #             if httpClient:
    #                 httpClient.close()