# # -*- coding: utf-8 -*-
# from openerp import http, fields
# from datetime import datetime
#
# try:
#     import cStringIO as StringIO
# except ImportError:
#     import StringIO
#
#
# date_ref = datetime.now().strftime('%Y-%m-%d')
# # _logger = logging.getLogger(__name__)
#
# class OrderController(http.Controller):
#     @http.route('/repertory//Login/<login>', type='http', auth='none', methods=['get'])
#     def Login(self,database,login,password):
#         1=1